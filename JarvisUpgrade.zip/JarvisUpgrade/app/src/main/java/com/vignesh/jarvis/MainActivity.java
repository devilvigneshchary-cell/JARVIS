package com.vignesh.jarvis;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    // Confirm the model ID against Anthropic's current model documentation if the API rejects it.
    private static final String MODEL = "claude-sonnet-5-5";
    private static final String[] LANG_CODES = {"en-IN", "te-IN", "hi-IN"};
    private static final String[] LANG_NAMES = {"English", "తెలుగు", "हिन्दी"};
    private static final int REQUEST_AUDIO = 41;
    private static final int BG = Color.rgb(5, 11, 22);
    private static final int CYAN = Color.rgb(56, 221, 248);
    private static final int WHITE = Color.rgb(232, 244, 250);
    private static final int MUTED = Color.rgb(132, 160, 178);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final JSONArray history = new JSONArray();
    private SharedPreferences preferences;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;
    private TextView conversation, status;
    private ScrollView scrollView;
    private EditText messageInput;
    private Button micButton, languageButton, sendButton;
    private int languageIndex = 0;
    private boolean listening = false;
    private boolean requestInProgress = false;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        buildInterface();
        tts = new TextToSpeech(this, this);
        appendMessage("JARVIS", "Systems online. Hello! Choose a language and ask me something.");
        updateStatus("READY • VOICE + AI");
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(14));
        root.setBackgroundColor(BG);

        TextView brand = new TextView(this);
        brand.setText("J A R V I S");
        brand.setTextColor(CYAN);
        brand.setTextSize(25);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL VOICE ASSISTANT");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(10);
        subtitle.setLetterSpacing(0.16f);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(24)));

        status = new TextView(this);
        status.setTextColor(CYAN);
        status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        LinearLayout topActions = new LinearLayout(this);
        topActions.setOrientation(LinearLayout.HORIZONTAL);
        languageButton = makeButton("LANGUAGE: ENGLISH");
        Button settingsButton = makeButton("API SETTINGS");
        Button clearButton = makeButton("CLEAR CHAT");
        topActions.addView(languageButton, weightedParams());
        topActions.addView(settingsButton, weightedParams());
        topActions.addView(clearButton, weightedParams());
        root.addView(topActions);

        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        conversation = new TextView(this);
        conversation.setTextColor(WHITE);
        conversation.setTextSize(15);
        conversation.setLineSpacing(dp(3), 1.0f);
        conversation.setPadding(dp(12), dp(14), dp(12), dp(14));
        scrollView.addView(conversation);
        LinearLayout.LayoutParams chatParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        chatParams.topMargin = dp(12);
        chatParams.bottomMargin = dp(12);
        root.addView(scrollView, chatParams);

        messageInput = new EditText(this);
        messageInput.setSingleLine(false);
        messageInput.setMaxLines(3);
        messageInput.setTextColor(WHITE);
        messageInput.setHintTextColor(MUTED);
        messageInput.setHint("Type a message for Jarvis...");
        messageInput.setTextSize(15);
        messageInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        messageInput.setBackground(roundDrawable(Color.rgb(15, 29, 45), CYAN, 1));
        messageInput.setImeOptions(EditorInfo.IME_ACTION_SEND);
        messageInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(messageInput, new LinearLayout.LayoutParams(-1, dp(54)));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        micButton = makeButton("🎙  SPEAK");
        sendButton = makeButton("SEND  ➤");
        bottom.addView(micButton, new LinearLayout.LayoutParams(0, dp(58), 1.2f));
        bottom.addView(sendButton, new LinearLayout.LayoutParams(0, dp(58), 1f));
        root.addView(bottom);
        setContentView(root);

        languageButton.setOnClickListener(v -> cycleLanguage());
        settingsButton.setOnClickListener(v -> showApiSettings());
        clearButton.setOnClickListener(v -> clearConversation());
        micButton.setOnClickListener(v -> startListening());
        sendButton.setOnClickListener(v -> sendTypedMessage());
        messageInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendTypedMessage(); return true; }
            return false;
        });
    }

    private LinearLayout.LayoutParams weightedParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setTextColor(CYAN);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(roundDrawable(Color.rgb(13, 27, 43), Color.rgb(28, 89, 111), 1));
        b.setPadding(dp(5), 0, dp(5), 0);
        return b;
    }

    private GradientDrawable roundDrawable(int fill, int stroke, int width) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(13));
        d.setStroke(dp(width), stroke);
        return d;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void cycleLanguage() {
        languageIndex = (languageIndex + 1) % LANG_CODES.length;
        languageButton.setText("LANGUAGE: " + LANG_NAMES[languageIndex].toUpperCase(Locale.ROOT));
        if (ttsReady) setTtsLanguage();
        updateStatus("LANGUAGE SET • " + LANG_NAMES[languageIndex]);
    }

    private void showApiSettings() {
        EditText keyField = new EditText(this);
        keyField.setSingleLine(true);
        keyField.setHint("Anthropic API key");
        keyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyField.setText(preferences.getString("api_key", ""));
        keyField.setPadding(dp(14), dp(12), dp(14), dp(12));
        new AlertDialog.Builder(this)
                .setTitle("AI API settings")
                .setMessage("Prototype only: a key stored on a phone can be extracted. Use a private backend for a public release.")
                .setView(keyField)
                .setPositiveButton("SAVE KEY", (dialog, which) -> {
                    String key = keyField.getText().toString().trim();
                    preferences.edit().putString("api_key", key).apply();
                    Toast.makeText(this, key.isEmpty() ? "API key cleared" : "API key saved on this device", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("REMOVE KEY", (dialog, which) -> preferences.edit().remove("api_key").apply())
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void sendTypedMessage() {
        String q = messageInput.getText().toString().trim();
        if (q.isEmpty()) return;
        messageInput.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(messageInput.getWindowToken(), 0);
        handleUserMessage(q);
    }

    private void startListening() {
        if (listening) {
            if (speechRecognizer != null) speechRecognizer.cancel();
            setListening(false);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            appendMessage("JARVIS", "Speech recognition is not available on this device. You can type instead.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { setListening(true); updateStatus("LISTENING..."); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { setListening(false); updateStatus("PROCESSING SPEECH..."); }
                @Override public void onError(int error) {
                    setListening(false);
                    updateStatus("VOICE INPUT READY");
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        appendMessage("JARVIS", "Voice input failed. Please try again or type your message.");
                    }
                }
                @Override public void onResults(Bundle results) {
                    setListening(false);
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) handleUserMessage(matches.get(0));
                    else updateStatus("VOICE INPUT READY");
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANG_CODES[languageIndex]);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, LANG_CODES[languageIndex]);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try { speechRecognizer.startListening(intent); }
        catch (Exception e) { appendMessage("JARVIS", "Could not start voice recognition. Please try again."); }
    }

    private void setListening(boolean value) {
        listening = value;
        micButton.setText(value ? "■  STOP" : "🎙  SPEAK");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening();
            else appendMessage("JARVIS", "Microphone permission is needed for voice input. Typing still works.");
        }
    }

    private void handleUserMessage(String query) {
        appendMessage("YOU", query);
        String lower = query.toLowerCase(Locale.ROOT).trim();
        if (tryOpenApp(lower)) return;
        askAssistant(query);
    }

    private boolean tryOpenApp(String query) {
        String[] prefixes = {"open ", "launch ", "ఓపెన్ ", "खोलो ", "खोल "};
        String appName = null;
        for (String prefix : prefixes) {
            if (query.startsWith(prefix)) { appName = query.substring(prefix.length()).replace(" app", "").trim(); break; }
        }
        if (appName == null || appName.isEmpty()) return false;
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(launcher, 0);
        for (ResolveInfo info : apps) {
            String label = info.loadLabel(pm).toString();
            if (label.equalsIgnoreCase(appName) || label.toLowerCase(Locale.ROOT).contains(appName)) {
                Intent launch = pm.getLaunchIntentForPackage(info.activityInfo.packageName);
                if (launch != null) {
                    appendMessage("JARVIS", "Opening " + label + ".");
                    try { startActivity(launch); } catch (Exception e) { appendMessage("JARVIS", "I couldn't open that app."); }
                    return true;
                }
            }
        }
        appendMessage("JARVIS", "I couldn't find an installed app named '" + appName + "'.");
        return true;
    }

    private void askAssistant(final String query) {
        if (requestInProgress) {
            appendMessage("JARVIS", "One request is already running. Please wait a moment.");
            return;
        }
        final String apiKey = preferences.getString("api_key", "").trim();
        if (apiKey.isEmpty()) {
            appendMessage("JARVIS", "Add your Anthropic API key in API SETTINGS to enable AI replies. App launching and typing remain available.");
            return;
        }
        requestInProgress = true;
        sendButton.setEnabled(false);
        updateStatus("CONNECTING TO JARVIS AI...");
        try { history.put(new JSONObject().put("role", "user").put("content", query)); }
        catch (Exception ignored) { }

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject();
                body.put("model", MODEL);
                body.put("max_tokens", 450);
                body.put("system", "You are JARVIS, a helpful personal voice assistant. Reply in the same language the user used: English, Telugu, or Hindi. Keep answers concise and easy to understand when read aloud. Do not claim to perform actions you cannot perform.");
                body.put("messages", history);

                connection = (HttpURLConnection) new URL(API_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(30000);
                connection.setRequestProperty("x-api-key", apiKey);
                connection.setRequestProperty("anthropic-version", "2023-06-01");
                connection.setRequestProperty("content-type", "application/json; charset=utf-8");
                connection.setDoOutput(true);
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream output = connection.getOutputStream()) { output.write(payload); }

                int responseCode = connection.getResponseCode();
                InputStream stream = responseCode >= 200 && responseCode < 300 ? connection.getInputStream() : connection.getErrorStream();
                String response = readFully(stream);
                JSONObject result = new JSONObject(response);
                if (responseCode < 200 || responseCode >= 300) {
                    history.remove(history.length() - 1);
                    JSONObject error = result.optJSONObject("error");
                    String message = error == null ? "HTTP " + responseCode : error.optString("message", "HTTP " + responseCode);
                    postReply("API error: " + message);
                } else {
                    JSONArray content = result.optJSONArray("content");
                    String answer = content != null && content.length() > 0
                            ? content.getJSONObject(0).optString("text", "I couldn't create a reply.")
                            : "I received an empty response. Please try again.";
                    history.put(new JSONObject().put("role", "assistant").put("content", answer));
                    postReply(answer);
                }
            } catch (Exception e) {
                if (history.length() > 0) history.remove(history.length() - 1);
                postReply("I couldn't connect. Check your internet and API settings, then try again.");
            } finally {
                if (connection != null) connection.disconnect();
                mainHandler.post(() -> {
                    requestInProgress = false;
                    sendButton.setEnabled(true);
                    updateStatus("READY • VOICE + AI");
                });
            }
        }, "JarvisNetwork").start();
    }

    private String readFully(InputStream input) throws Exception {
        if (input == null) return "{}";
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) output.append(line);
        }
        return output.toString();
    }

    private void postReply(String text) {
        mainHandler.post(() -> {
            appendMessage("JARVIS", text);
            if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply");
        });
    }

    private void appendMessage(String speaker, String text) {
        conversation.append(speaker + "\n");
        conversation.append(text + "\n\n");
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void clearConversation() {
        while (history.length() > 0) history.remove(0);
        conversation.setText("");
        appendMessage("JARVIS", "Conversation cleared. Ready for your next command.");
    }

    private void updateStatus(String text) { if (status != null) status.setText("◈  " + text); }

    @Override
    public void onInit(int result) {
        ttsReady = result == TextToSpeech.SUCCESS;
        if (ttsReady) setTtsLanguage();
    }

    private void setTtsLanguage() {
        if (tts == null) return;
        int result = tts.setLanguage(Locale.forLanguageTag(LANG_CODES[languageIndex]));
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "This voice is not installed. Install the language voice data in Android settings.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
