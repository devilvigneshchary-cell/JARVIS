# JARVIS Android app — upgraded starter project

## Included
- Dark cyan sci-fi inspired interface
- English, Telugu and Hindi speech recognition selection
- Text chat fallback
- Text-to-speech replies
- App launching by commands such as `open WhatsApp`
- Anthropic Messages API integration
- API settings dialog, request timeouts, basic error handling
- Clear-chat action and GitHub Actions APK build workflow

## Open and build
1. Open this folder in Android Studio (Open an existing project).
2. Let Gradle sync finish.
3. Run on an Android device or emulator (Android 8.0 / API 26 or newer).
4. Grant microphone permission when prompted.
5. Add an Anthropic API key in **API SETTINGS** for AI replies.

The GitHub Actions workflow is at `.github/workflows/build.yml`. Push the project to a GitHub repository and run the **Build JARVIS APK** workflow; the debug APK is uploaded as an artifact.

## Important security note
This is a learning/prototype implementation. An API key stored by a mobile app can be extracted from the device or app process. Do not distribute this build publicly or embed a personal/paid API key in a released APK. For a public release, move the Anthropic API call to a private server you control, authenticate app users, and keep the provider key only on that server. Do not paste your API key into chat.

## Model configuration
The model ID is configured in `MainActivity.java` as `MODEL`. If Anthropic retires or rejects that model ID, update it to a currently supported model in Anthropic's official API documentation.

## Current limitations
- App launching supports matching installed launcher labels; it does not control apps after opening them.
- Speech recognition and text-to-speech language availability depend on the phone's installed speech services and voice data.
- This prototype does not include wake-word listening, background microphone service, cloud sync, or secure account management.
